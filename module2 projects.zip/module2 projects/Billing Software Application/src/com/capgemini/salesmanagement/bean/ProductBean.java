package com.capgemini.salesmanagement.bean;

public class ProductBean {

		private int productCode;
	private String productName;
	private String productDescription;
	private double productPrice;
	private int quantity;
	private double totalLine;
	private String productCatagory;
	
	public String getProductCatagory() {
		return productCatagory;
	}
	public void setProductCatagory(String productCatagory) {
		this.productCatagory = productCatagory;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTotalLine() {
		return totalLine;
	}
	public void setTotalLine(double totalLine) {
		this.totalLine = totalLine;
	}
	
	
	}
	
	
	
