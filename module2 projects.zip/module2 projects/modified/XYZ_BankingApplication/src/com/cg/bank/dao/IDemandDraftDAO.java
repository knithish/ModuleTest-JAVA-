package com.cg.bank.dao;

import java.io.IOException;

import com.capgemini.salesmanagement.exception.ProductException;
import com.cg.bank.bean.DemandDraft;

public interface IDemandDraftDAO {
	int addDemandDraftDetails (DemandDraft demandDraft) throws ProductException, IOException;
	DemandDraft getDemandDraftDetails (int transactionId);
}
