package com.cg.bank.service;
import java.io.IOException;

import com.capgemini.salesmanagement.exception.ProductException;
import com.cg.bank.bean.DemandDraft;

public interface IDemandDraftService {
	int addDemandDraftDetails (DemandDraft demandDraft) throws ProductException, IOException;
	DemandDraft getDemandDraftDetails (int transactionId);
}

